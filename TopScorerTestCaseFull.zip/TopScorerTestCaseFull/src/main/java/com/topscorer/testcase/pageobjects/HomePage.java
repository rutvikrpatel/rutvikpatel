/**
 * 
 */
package com.topscorer.testcase.pageobjects;

import org.openqa.selenium.WebDriver;

import com.topscorer.testcase.components.Menu;

/**
 * @author SPConlin
 *
 */
public class HomePage extends Page {
	
	/**
	 * @param driver
	 */
	public HomePage(WebDriver driver) {
		super(driver);
	}

	/**
	 * @param driver
	 * @param pageTitle
	 */
	public HomePage(WebDriver driver, String pageTitle) {
		super(driver, pageTitle);
	}
	
	public Menu getMenu() {
		return new Menu(driver);
	}

}
