package com.topscorer.testcase;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MainDemo {
	
	public static WebDriver driver;
	
	public static void main(String[] args) throws InterruptedException {
		
		/*
		 * Top Scorer Test Case Of Select 'GSEB GUJ -> STD 9' and go to that Page
		 * 
		 * 1. click 'Courses' 
		 * 2. hover/find element 'GSEB GUJ'
		 * 3. click on 'GSEB GUJ'
		 * 4. hover/find element on 'STD 9'
		 * 5. click on 'STD 9'
		 * 6. page redirected to 'GSEB GUJ -> STD 9'
		 */
		
		System.setProperty( "webdriver.chrome.driver" , "E:\\chromedriver.exe" );
		driver = new ChromeDriver();
		driver.manage().window(); // .maximize();
		
		driver.get("https://www.topscorer.com");
		// implicit wait
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		System.out.println("browser open...");
		
		By coursesMenuLocator = By.xpath("/html/body/nav/div/ul/li/a");
		WebDriverWait wait = new WebDriverWait(driver, 5);
		WebElement coursesArticles = wait.until(ExpectedConditions.elementToBeClickable(coursesMenuLocator));
		//WebElement coursesArticles = driver.findElement(coursesMenuLocator);
		coursesArticles.click();
		System.out.println("select courses...");
		
		By gsebMenuLocator = By.xpath("/html/body/nav/div/ul/li/ul/li[1]/a");
		WebElement gsebArticles = wait.until(ExpectedConditions.elementToBeClickable(gsebMenuLocator));
		//WebElement gsebArticles = driver.findElement(gsebMenuLocator);
		gsebArticles.findElement(gsebMenuLocator);
		gsebArticles.click();
		System.out.println("select gseb...");
		
		By std9MenuLocator = By.xpath("/html/body/nav/div/ul/li/ul/li[1]/ul/li[9]/a");
		WebElement std9Articles = wait.until(ExpectedConditions.elementToBeClickable(std9MenuLocator));
		//WebElement std9Articles = driver.findElement(std9MenuLocator);
		std9Articles.findElement(std9MenuLocator);
		std9Articles.click();
		System.out.println("select std9...");
		
		// explicit wait
		Thread.sleep(7000);
		driver.quit();
		
		
		/*
		 * open google and find keyword
		
		WebDriver driver = new ChromeDriver();
		driver.get("http://www.google.com/xhtml");
		Thread.sleep(3000);
		
		WebElement searchBox = driver.findElement(By.name("q"));
		searchBox.sendKeys("rutvikpatel.com");
		searchBox.submit();
		Thread.sleep(3000);
		driver.quit();
		*/
		
		
		
		/*
		 * go to google home page and go to images link
		 * 
		 * Custom Class Created
		
		MainDemo browser = new MainDemo();
		browser.startBrowser();
		
		browser.gotoUrl("http://www.google.com/xhtml");
		browser.waitForSecond(3);
		
		By itemLocator = By.xpath("//*[@id='gbw']/div/div/div[1]/div[2]/a");
		
		//By menuItemLocator = By.id("menu-item-193");
		WebElement articles = driver.findElement(itemLocator);
		articles.click();
		
		browser.QuitBrowser();
		*/
	}
	
	
	/*
	 * Browser level methods are below
	 * */
	
	// start browser
	public void startBrowser(){
		System.setProperty( "webdriver.chrome.driver" , "E:\\chromedriver.exe" );
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		System.out.println(">>> Browser Opened");
	}
	
	// go to any url
	public void gotoUrl( String url ) {
		driver.get( url.trim() );
		//driver.navigate().to( url.trim() );
		System.out.println(">>> Browser URL Opened ::: "+url);
	}
	
	// close browser
	public void QuitBrowser() {
		waitForSecond(3);
		driver.quit();
		System.out.println(">>> Browser Closed");
	}
	
	// wait for second
	public void waitForSecond( long sec ) {
		try {
			Thread.sleep( sec*1000 );
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	
	/*
	 * Element level methods are below 
	 * */
	
	// get element by id
	public By getElementById( String id ){
		return By.id( id.trim() );
	}
	
	// get element by xpath
	public By getElementByXPath( String xPath ){
		return By.xpath( xPath.trim() );
	}
	
	// click on that element
	public void clickOnWebElement( WebElement webElement ){
		webElement.click();
	}
	
	// find web element by any By object
	public WebElement findElement( By ele ){
		return driver.findElement(ele);
	}
	
	
	
	/*
	 * Testing code are below
	 */
	
	/*
	// find web element & click
	WebElement articles = driver.findElement(menuItemLocator);
	articles.click();
	
	// find web element and enter keyword and submit form
	WebElement searchBox = searchCont.findElement(searchBoxLocator);
	searchBox.sendKeys("hello");
	searchBox.submit();
	
	// ID
	By menuItemLocator = By.id("menu-item-193");
	
	// Name
	By searchBoxLocator = By.name("s");
	
	// XPath
	By searchBoxLoc = By.xpath("//*[@id='search-2']/form/label/input");
	
	// CSS Selector
	By searchBoxLocCSS = By.cssSelector("#search-2 > form > label > input");
	
	// Link Text
	By linktext = By.linkText("Using Page Objects");
	
	// Partial Link Text
	By partialLinkText = By.partialLinkText("Page Objects");
	
	// Class Name
	By className = By.className("main-content");
	
	// Tag Name
	By tagName = By.tagName("h2");
	*/
}