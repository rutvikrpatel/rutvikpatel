package com.topscorer.testcase;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserAction {
	
	public static WebDriver driver;
	
	
	/*
	 * Browser level methods are below
	 * */
	
	// start browser
	public void startBrowser(){
		System.setProperty("webdriver.chrome.driver", "E:\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		System.out.println(">>> Browser Opened");
	}
	
	// go to any url
	public void gotoUrl(String url) {
		driver.get(url.trim());
		System.out.println(">>> Browser URL Opened ::: "+url);
	}
	
	// close browser
	public void QuitBrowser() {
		waitForSecond(3);
		driver.quit();
		System.out.println(">>> Browser Closed");
	}
	
	// wait for second
	public void waitForSecond(long sec) {
		try {
			Thread.sleep(sec*1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	
	/*
	 * Element level methods are below 
	 * */
	
	// get element by id
	public By getElementById(String id){
		return By.id( id.trim() );
	}
	
	// get element by xPath
	public By getElementByXPath(String xPath){
		return By.xpath(xPath.trim());
	}
	
	// click on that element
	public void clickOnWebElement(WebElement webElement){
		webElement.click();
	}
	
	// find web element by any By object
	public WebElement findElement(By ele){
		return driver.findElement(ele);
	}
}